package hello.two.hellotwospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloTwoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
